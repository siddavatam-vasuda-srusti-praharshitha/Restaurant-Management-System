
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertCustomer extends Panel 
{
	Button insertCustomerButton;
	TextField cidText, cnameText, addressText, mailText,passwordText,phoneText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertCustomer() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI()  
	{		
		insertCustomerButton = new Button("Submit");
		insertCustomerButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				 Statement statement = connection.createStatement();
				  				  
				 String query= "INSERT INTO Customer VALUES('" + cidText.getText() + "', " + "'" + passwordText.getText() + "'," + "'" + mailText.getText() + "',"+"'"+cnameText.getText()+"'," +"'"+addressText.getText()+"',"+phoneText.getText()+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		cnameText = new TextField(15);
		cidText = new TextField(15);
		addressText = new TextField(15);
		mailText = new TextField(15);
	    passwordText = new TextField(15);
	   phoneText = new TextField(15);
	

		
		errorText = new TextArea(10,40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6,2));
		first.add(new Label("Customer ID:"));
		first.add(cidText);
		first.add(new Label("Name:"));
		first.add(cnameText);
		first.add(new Label("Address:"));
		first.add(addressText);
		first.add(new Label("Mail"));
		first.add(mailText);
		first.add(new Label("Password:"));
		first.add(passwordText);
		first.add(new Label("Phone:"));
		first.add(phoneText);
		

		first.setBounds(125,90,300,150);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertCustomerButton);
		second.setBounds(195,290,150,100);       
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(80,410,430,300);
		setLayout(null);
	
		add(first);
		add(second);
		add(third);
	    
		setSize(500,600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertCustomer incus = new InsertCustomer();

			
		incus.buildGUI();
	}
}
