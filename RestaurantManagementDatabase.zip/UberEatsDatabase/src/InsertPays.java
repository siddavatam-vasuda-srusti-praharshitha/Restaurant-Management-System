import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertPays extends Panel 
{
	Button PaysButton;
	Choice tidSelect, cidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertPays() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCustomer() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Customer");
		  while (rs.next()) 
		  {
			cidSelect.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadPayment() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Payment");
		  while (rs.next()) 
		  {
			tidSelect.add(rs.getString("TID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	
	public void buildGUI() 
	{		
	    tidSelect = new Choice();
		loadPayment();
		
		cidSelect = new Choice();
		loadCustomer();
		
		
	    
		PaysButton = new Button("Submit");
		PaysButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();			  
				  String query= "INSERT INTO Orders VALUES(" + tidSelect.getSelectedItem() + ", '" + cidSelect.getSelectedItem()+ "'" +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Customer ID:"));
		first.add(cidSelect);
		first.add(new Label("Transaction ID:"));
		first.add(tidSelect);

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(PaysButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertPays inpays = new InsertPays();

		inpays.buildGUI();
	}
}

