
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteOrder extends Panel 
{
	Button deleteOrderButton;
	List OrderIDList;
	TextField oidText, priceText, timeText, locationText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteOrder() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadOrder() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM OrderDetails");
		  while (rs.next()) 
		  {
			OrderIDList.add(rs.getString("OID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    OrderIDList = new List(10);
		loadOrder();
		add(OrderIDList);
		
		//When a list item is selected populate the text fields
		OrderIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM OrderDetails");
					while (rs.next()) 
					{
						if (rs.getString("OID").equals(OrderIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						locationText.setText(rs.getString("LOCATION"));
						priceText.setText(rs.getString("PRICE"));
						timeText.setText(rs.getString("TIME"));
						oidText.setText(rs.getString("OID"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		deleteOrderButton = new Button("Delete");
		deleteOrderButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM OrderDetails WHERE OID = "
							+OrderIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					locationText.setText(null);
					priceText.setText(null);
					timeText.setText(null);
					oidText.setText(null);
					OrderIDList.removeAll();
					loadOrder();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		oidText = new TextField(15);
		locationText = new TextField(15);
		priceText = new TextField(15);
		timeText = new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Order ID:"));
		first.add(oidText);
		oidText.setEditable(false);
		first.add(new Label("Location:"));
		first.add(locationText);
		locationText.setEditable(false);
		first.add(new Label("Price:"));
		first.add(priceText);
		priceText.setEditable(false);
		first.add(new Label("Time:"));
		first.add(timeText);
		timeText.setEditable(false);
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteOrderButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteOrder delo = new DeleteOrder();
		delo.buildGUI();
	}
}


