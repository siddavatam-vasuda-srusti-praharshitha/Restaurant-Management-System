import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertOrderFrom extends Panel 
{
	Button OrderFromButton;
	Choice ridSelect, cidSelect;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public InsertOrderFrom() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCustomer() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Customer");
		  while (rs.next()) 
		  {
			cidSelect.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	private void loadRestaurant() 
	{
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM UberEats");
		  while (rs.next()) 
		  {
			ridSelect.add(rs.getString("RID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
			
	}
	
	
	public void buildGUI() 
	{		
	    ridSelect = new Choice();
		loadRestaurant();
		
		cidSelect = new Choice();
		loadCustomer();
		
		
	    
		OrderFromButton = new Button("Submit");
		OrderFromButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				  Statement statement = connection.createStatement();			  
				  String query= "INSERT INTO OrderFrom VALUES('" + cidSelect.getSelectedItem() + "', '" + ridSelect.getSelectedItem()+ "'" +")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Customer ID:"));
		first.add(cidSelect);
		first.add(new Label("Restaurant ID:"));
		first.add(ridSelect);

		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(OrderFromButton);
		
		Panel third = new Panel();
		third.add(errorText);			

		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertOrderFrom inordf = new InsertOrderFrom();

		inordf.buildGUI();
	}
}

