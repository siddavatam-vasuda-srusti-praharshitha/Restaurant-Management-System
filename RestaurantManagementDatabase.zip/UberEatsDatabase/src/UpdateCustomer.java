import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateCustomer extends Panel 
{
	Button updateCustomerButton;
	List CustomerIDList;
	TextField cidText,cnameText, mailText, passwordText,addressText,phoneText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateCustomer()
	
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadCustomer() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT CID FROM Customer");
		  while (rs.next()) 
		  {
			CustomerIDList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    CustomerIDList = new List(10);
		loadCustomer();
		add(CustomerIDList);
		
		//When a list item is selected populate the text fields
	CustomerIDList.addItemListener(new ItemListener()
		{
		public void itemStateChanged(ItemEvent e) 
		{
			try 
			{
				rs = statement.executeQuery("SELECT * FROM Customer");
				while (rs.next()) 
				{
					if (rs.getString("CID").equals(CustomerIDList.getSelectedItem()))
					break;
				}
				if (!rs.isAfterLast()) 
				{
					cidText.setText(rs.getString("CID"));
					passwordText.setText(rs.getString("Password"));
					mailText.setText(rs.getString("Mail"));
					cnameText.setText(rs.getString("Name"));
					addressText.setText(rs.getString("Address"));
					phoneText.setText(rs.getString("Phone"));
				}
			} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		updateCustomerButton = new Button("Modify");
		updateCustomerButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE Customer "
					+ "SET password='" + passwordText.getText() + "', "
					+ "mail='" + mailText.getText() + "', "
					+ "name ='"+ cnameText.getText()+"',"
					+"address ='"+ addressText.getText()+"',"
					+"phone=" +phoneText.getText()+ " WHERE Cid = '"
					+ CustomerIDList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					CustomerIDList.removeAll();
					loadCustomer();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		cidText.setEditable(false);
		cnameText = new TextField(15);
		mailText = new TextField(15);
		passwordText = new TextField(15);
		addressText=new TextField(15);
		phoneText=new TextField(15);
		
		
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 2));
		first.add(new Label("Customer ID:"));
		first.add(cidText);
		first.add(new Label("Name:"));
		first.add(cnameText);
		first.add(new Label("Mail:"));
		first.add(mailText);
		first.add(new Label("Password:"));
		first.add(passwordText);
		first.add(new Label("Address:"));
		first.add(addressText);
		first.add(new Label("Phone:"));
		first.add(phoneText);
		
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(updateCustomerButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateCustomer upc = new UpdateCustomer();

	
		upc.buildGUI();
	}
}
