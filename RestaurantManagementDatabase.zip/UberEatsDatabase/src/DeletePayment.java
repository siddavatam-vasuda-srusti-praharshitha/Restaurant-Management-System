import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeletePayment extends Panel 
{
	Button deletePaymentButton;
	List TransactionIDList;
	TextField tidText, dateText,timeText, typeText,cashText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeletePayment() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadPayment() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Payment");
		  while (rs.next()) 
		  {
			TransactionIDList.add(rs.getString("TID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    TransactionIDList = new List(10);
		loadPayment();
		add(TransactionIDList);
		
		//When a list item is selected populate the text fields
		TransactionIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Payment");
					while (rs.next()) 
					{
						if (rs.getString("TID").equals(TransactionIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						dateText.setText(rs.getString("DT"));
						timeText.setText(rs.getString("TM"));
						typeText.setText(rs.getString("TYPE"));
						cashText.setText(rs.getString("CASH"));
						tidText.setText(rs.getString("TID"));
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		deletePaymentButton = new Button("Delete");
		deletePaymentButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Payment WHERE TID = "
							+ TransactionIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
					dateText.setText(null);
					timeText.setText(null);
					typeText.setText(null);
					cashText.setText(null);
					tidText.setText(null);
					TransactionIDList.removeAll();
					loadPayment();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tidText = new TextField(15);
		cashText = new TextField(15);
		typeText = new TextField(15);
		dateText = new TextField(15);
		timeText= new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Transaction ID:"));
		first.add(tidText);
		tidText.setEditable(false);
		first.add(new Label("Cash:"));
		first.add(cashText);
		cashText.setEditable(false);
		first.add(new Label("Type:"));
		first.add(typeText);
		typeText.setEditable(false);
		first.add(new Label("Date:"));
		first.add(dateText);
		dateText.setEditable(false);
		first.add(new Label("Time:"));
		first.add(timeText);
		timeText.setEditable(false);
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deletePaymentButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeletePayment delp = new DeletePayment();
		delp.buildGUI();
	}
}

