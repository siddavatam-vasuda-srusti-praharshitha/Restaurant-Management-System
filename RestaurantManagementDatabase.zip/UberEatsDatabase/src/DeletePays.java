import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeletePays extends Panel 
{
	Button deletePaysButton;
	List PaysIDList;
	TextField tidText, cidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeletePays() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadPays() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Pays");
		  while (rs.next()) 
		  {
			PaysIDList.add(rs.getString("CID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	   PaysIDList = new List(10);
		loadPays();
		add(PaysIDList);
		
		PaysIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Pays");
					while (rs.next()) 
					{
						if (rs.getString("CID").equals(PaysIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						cidText.setText(rs.getString("CID"));
						tidText.setText(rs.getString("TID"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		deletePaysButton = new Button("Delete");
		deletePaysButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Pays WHERE CID = '"
							+ PaysIDList.getSelectedItem()+"'");
					errorText.append("\nDeleted " + i + " rows successfully");
				    tidText.setText(null);
					cidText.setText(null);
					
					PaysIDList.removeAll();
					loadPays();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		cidText = new TextField(15);
		tidText = new TextField(15);
	
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Customer ID:"));
		first.add(cidText);
		cidText.setEditable(false);
		first.add(new Label("Transaction ID:"));
		first.add(tidText);
		tidText.setEditable(false);
		
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deletePaysButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeletePays delpays = new DeletePays();
		delpays.buildGUI();
	}
}



