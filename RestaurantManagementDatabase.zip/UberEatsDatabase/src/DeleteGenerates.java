import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class DeleteGenerates extends Panel 
{
	Button deleteGeneratesButton;
	List GeneratesIDList;
	TextField tidText, oidText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public DeleteGenerates() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadGenerates() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT * FROM Generates");
		  while (rs.next()) 
		  {
			GeneratesIDList.add(rs.getString("OID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	   GeneratesIDList = new List(10);
		loadGenerates();
		add(GeneratesIDList);
		
		GeneratesIDList.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e) 
			{
				try 
				{
					rs = statement.executeQuery("SELECT * FROM Generates");
					while (rs.next()) 
					{
						if (rs.getString("OID").equals(GeneratesIDList.getSelectedItem()))
						break;
					}
					if (!rs.isAfterLast()) 
					{
						oidText.setText(rs.getString("OID"));
						tidText.setText(rs.getString("TID"));
						
					}
				} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		deleteGeneratesButton = new Button("Delete");
		deleteGeneratesButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("DELETE FROM Generates WHERE OID = "
							+ GeneratesIDList.getSelectedItem());
					errorText.append("\nDeleted " + i + " rows successfully");
				    tidText.setText(null);
					oidText.setText(null);
					
					GeneratesIDList.removeAll();
					loadGenerates();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		tidText = new TextField(15);
		oidText = new TextField(15);
	
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6, 1));
		first.add(new Label("Order ID:"));
		first.add(oidText);
		oidText.setEditable(false);
		first.add(new Label("Transaction ID:"));
		first.add(tidText);
		tidText.setEditable(false);
		
		
		

		Panel second = new Panel(new GridLayout(4, 1));
		second.add(deleteGeneratesButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(450, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
		
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		DeleteGenerates delgen = new DeleteGenerates();
		delgen.buildGUI();
	}
}



