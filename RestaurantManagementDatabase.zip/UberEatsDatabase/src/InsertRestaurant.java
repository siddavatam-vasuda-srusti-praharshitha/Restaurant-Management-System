
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertRestaurant extends Panel 
{
	Button insertRestaurantButton;
	TextField ridText, locationText, ratingText, foodmenuText,openclosetimeText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertRestaurant() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI()  
	{		
		insertRestaurantButton = new Button("Submit");
		insertRestaurantButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				 Statement statement = connection.createStatement();
				  				  
				 String query= "INSERT INTO UberEats VALUES(" + openclosetimeText.getText() + ", " + "'" + locationText.getText() + "',"  + ratingText.getText() + ","+"'"+ridText.getText()+"'," +"'"+foodmenuText.getText()+"'"+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		ridText = new TextField(15);
		locationText = new TextField(15);
		foodmenuText = new TextField(15);
		openclosetimeText = new TextField(15);
	    ratingText = new TextField(15);
	

		
		errorText = new TextArea(10,40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6,2));
		first.add(new Label("Restaurant ID:"));
		first.add(ridText);
		first.add(new Label("Location:"));
		first.add(locationText);
		first.add(new Label("Food Menu:"));
		first.add(foodmenuText);
		first.add(new Label("Open Close Time:"));
		first.add(openclosetimeText);
		first.add(new Label("Rating:"));
		first.add(ratingText);
		

		first.setBounds(125,90,300,150);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertRestaurantButton);
		second.setBounds(195,290,150,100);       
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(80,410,430,300);
		setLayout(null);
	
		add(first);
		add(second);
		add(third);
	    
		setSize(500,600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertRestaurant res= new InsertRestaurant();

			
		res.buildGUI();
	}
}
