import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class UpdateRestaurant extends Panel 
{
	Button updateRestaurantButton;
	List RestaurantIDList;
	TextField ridText,openclosetimeText, locationText, ratingText,foodmenuText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	ResultSet rs;
	
	public UpdateRestaurant()
	
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	
	private void loadRestaurant() 
	{	   
		try 
		{
		  rs = statement.executeQuery("SELECT RID FROM UberEats");
		  while (rs.next()) 
		  {
			RestaurantIDList.add(rs.getString("RID"));
		  }
		} 
		catch (SQLException e) 
		{ 
		  displaySQLErrors(e);
		}
	}
	
	public void buildGUI() 
	{		
	    RestaurantIDList = new List(10);
		loadRestaurant();
		add(RestaurantIDList);
		
		//When a list item is selected populate the text fields
	RestaurantIDList.addItemListener(new ItemListener()
		{
		public void itemStateChanged(ItemEvent e) 
		{
			try 
			{
				rs = statement.executeQuery("SELECT * FROM UberEats");
				while (rs.next()) 
				{
					if (rs.getString("RID").equals(RestaurantIDList.getSelectedItem()))
					break;
				}
				if (!rs.isAfterLast()) 
				{
					openclosetimeText.setText(rs.getString("OPENCLOSETIME"));
					locationText.setText(rs.getString("LOCATION"));
					ratingText.setText(rs.getString("RATING"));
					ridText.setText(rs.getString("RID"));
					foodmenuText.setText(rs.getString("FOODMENU"));
				}
			} 
				catch (SQLException selectException) 
				{
					displaySQLErrors(selectException);
				}
			}
		});		
		
	    
		updateRestaurantButton = new Button("Modify");
		updateRestaurantButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
					Statement statement = connection.createStatement();
					int i = statement.executeUpdate("UPDATE UberEats "
					+ "SET openclosetime=" + openclosetimeText.getText() + ", "
					+ "location='" + locationText.getText() + "', "
					+ "rating ="+ ratingText.getText()+","+"foodmenu='" +foodmenuText.getText()+"',"+ " WHERE Rid = '"
					+RestaurantIDList.getSelectedItem()+"'");
					errorText.append("\nUpdated " + i + " rows successfully");
					RestaurantIDList.removeAll();
					loadRestaurant();
				} 
				catch (SQLException insertException) 
				{
					displaySQLErrors(insertException);
				}
			}
		});
		
		ridText = new TextField(15);
		ridText.setEditable(false);
		openclosetimeText = new TextField(15);
		locationText = new TextField(15);
		ratingText = new TextField(15);
		foodmenuText=new TextField(15);
		
		errorText = new TextArea(10, 40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(5, 2));
		first.add(new Label("Restaurant ID:"));
		first.add(ridText);
		first.add(new Label("Location:"));
		first.add(locationText);
		first.add(new Label("Food Menu:"));
		first.add(foodmenuText);
		first.add(new Label("Open Close Time:"));
		first.add(openclosetimeText);
		first.add(new Label("Rating:"));
		first.add(ratingText);
		
		Panel second = new Panel(new GridLayout(5, 1));
		second.add(updateRestaurantButton);
		
		Panel third = new Panel();
		third.add(errorText);
		
		add(first);
		add(second);
		add(third);
	    
		setSize(500, 600);
		setLayout(new FlowLayout());
		setVisible(true);
		
	}

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	public static void main(String[] args) 
	{
		UpdateRestaurant upub = new UpdateRestaurant();

	
		upub.buildGUI();
	}
}
