
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class InsertPayment extends Panel 
{
	Button insertPaymentButton;
	TextField tidText, dateText, cashText, timeText,typeText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	public InsertPayment() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
	}

	public void connectToDB() 
    {
		try 
		{
		  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","OracleDBMS2090&");
		  statement = connection.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	public void buildGUI()  
	{		

		insertPaymentButton = new Button("Submit");
		insertPaymentButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				try 
				{
				 Statement statement = connection.createStatement();
				  				  
				 String query= "INSERT INTO Payment VALUES('" + dateText.getText() + "',"+ "'"  + timeText.getText() + "',"+ "'"  + typeText.getText() + "',"+ cashText.getText()+"," + tidText.getText()+")";
				  int i = statement.executeUpdate(query);
				  errorText.append("\nInserted " + i + " rows successfully");
				} 
				catch (SQLException insertException) 
				{
				  displaySQLErrors(insertException);
				}
			}
		});

	
		tidText = new TextField(15);
		typeText = new TextField(15);
		dateText = new TextField(15);
		timeText = new TextField(15);
		cashText = new TextField(15);
		
	

		
		errorText = new TextArea(10,40);
		errorText.setEditable(false);

		Panel first = new Panel();
		first.setLayout(new GridLayout(6,2));
		first.add(new Label("Transaction ID:"));
		first.add(tidText);
		first.add(new Label("Mode of Payment:"));
		first.add(typeText);
		first.add(new Label("Date:"));
		first.add(dateText);
		first.add(new Label("Time:"));
		first.add(timeText);
		first.add(new Label("Cash:"));
		first.add(cashText);
		

		first.setBounds(125,90,300,150);
		
		Panel second = new Panel(new GridLayout(4, 1));
		second.add(insertPaymentButton);
		second.setBounds(195,290,150,100);       
		
		Panel third = new Panel();
		third.add(errorText);
		third.setBounds(80,410,430,300);
		setLayout(null);
	
		add(first);
		add(second);
		add(third);
	    
		setSize(500,600);
		setVisible(true);
	}

	

	private void displaySQLErrors(SQLException e) 
	{
		errorText.append("\nSQLException: " + e.getMessage() + "\n");
		errorText.append("SQLState:     " + e.getSQLState() + "\n");
		errorText.append("VendorError:  " + e.getErrorCode() + "\n");
	}

	

	public static void main(String[] args) 
	{
		InsertPayment paym = new InsertPayment();

			
		paym.buildGUI();
	}
}
