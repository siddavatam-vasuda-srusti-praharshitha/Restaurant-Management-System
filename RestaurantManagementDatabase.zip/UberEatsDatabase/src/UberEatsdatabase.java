import java.awt.*; 
import java.awt.event.*; 

class UberEatsDatabase extends Frame implements ActionListener
{ 
	  String msg = ""; 
	  Label ll,l2;
	  
	  CardLayout cardLO;
	  
	  InsertCustomer incus;
	  UpdateCustomer upcus;
	  DeleteCustomer delcus;
	  InsertRestaurant inres;
	  UpdateRestaurant upres;
	  DeleteRestaurant delres;
	  InsertOrder ino;
	  DeleteOrder delo;
	  UpdateOrder upo;
	  InsertPayment inpay;
	  UpdatePayment uppay;
	  DeletePayment delpay;
	  InsertOrders inords;
	  UpdateOrders upords;
	  DeleteOrders delords;
	  InsertOrderFrom inorf;
	  UpdateOrderFrom uporf;
	  DeleteOrderFrom delorf;
	  InsertPays inpays;
	  UpdatePays uppays;
	  DeletePays delpays;
	  InsertGenerates ingen;
	  UpdateGenerates upgen;
	  DeleteGenerates delgen;
	  
	  Panel home,welcome; 
	  
	 UberEatsDatabase() 
	  { 
			cardLO = new CardLayout(); 
			
			home = new Panel(); 
			home.setLayout(cardLO);  

			
			ll = new Label();
			l2 =new Label();
			ll.setAlignment(Label.CENTER);  
			l2.setAlignment(Label.CENTER); 
			ll.setText("Welcome to UBER EATS");
			l2.setText("\nAll @rights are reserved");
			//Create welcome panel and add the label to it
			welcome = new Panel();
			welcome.add(ll);
			welcome.add(l2);
			
			//create panels for each of our menu items and build them with respective components
			incus = new InsertCustomer(); incus.buildGUI();
			upcus = new UpdateCustomer();  upcus.buildGUI();
			delcus = new DeleteCustomer();	delcus.buildGUI();
			inres = new InsertRestaurant();inres.buildGUI();
			upres= new UpdateRestaurant();upres.buildGUI();
			delres = new DeleteRestaurant();delres.buildGUI();
			ino = new InsertOrder();ino.buildGUI();
			delo = new DeleteOrder();delo.buildGUI();
			upo= new UpdateOrder();upo.buildGUI();
			inpay= new InsertPayment();	inpay.buildGUI();
			uppay= new UpdatePayment();uppay.buildGUI();
			delpay = new DeletePayment(); delpay.buildGUI();
			inords = new InsertOrders();inords.buildGUI();
			upords = new UpdateOrders();upords.buildGUI();
			delords = new DeleteOrders();delords.buildGUI();
			inorf = new InsertOrderFrom();inorf.buildGUI();
			delorf = new DeleteOrderFrom();delorf.buildGUI();
			uporf = new UpdateOrderFrom();uporf.buildGUI();
			inpays = new InsertPays();inpays.buildGUI();
			delpays = new DeletePays();delpays.buildGUI();
			uppays = new UpdatePays();uppays.buildGUI();
			ingen = new InsertGenerates();ingen.buildGUI();
			delgen = new DeleteGenerates();delgen.buildGUI();
			upgen = new UpdateGenerates();upgen.buildGUI();
			
			
			
			//add all the panels to the home panel which has a cardlayout
			home.add(welcome, "Welcome"); 
			home.add(incus, "InsertCustomer"); 
			home.add(upcus, "UpdateCustomer"); 
			home.add(delcus, "DeleteCustomer"); 
			home.add(inres,"InsertRestaurant");
			home.add(upres,"UpdateRestaurant");
			home.add(delres,"DeleteRestaurant");
			home.add(ino,"InsertOrder");
			home.add(delo,"DeleteOrder");
			home.add(upo,"UpdateOrder");
			home.add(inpay,"InsertPayment");
			home.add(uppay,"UpdatePayment");
			home.add(delpay,"DeletePayment");
			home.add(inords,"InsertOrders");
			home.add(upords,"UpdateOrders");
			home.add(delords,"DeleteOrders");
			home.add(inpays,"InsertPays");
			home.add(delpays,"DeletePays");
			home.add(uppays,"UpdatePays");
			home.add(inorf,"InsertOrderFrom");
			home.add(delorf,"DeleteOrderFrom");
			home.add(uporf,"UpdateOrderFrom");
			home.add(ingen,"InsertGenerates");
			home.add(delgen,"DeleteGenerates");
			home.add(upgen,"UpdateGenerates");
			
			
			
		 
			// add home panel to main frame  
			add(home); 
		 
			// create menu bar and add it to frame 
			MenuBar mbar = new MenuBar(); 
			setMenuBar(mbar); 
		 
			// create the menu items and add it to Menu
			Menu customer= new Menu("Customer Details"); 
			MenuItem item1, item2, item3; 
			customer.add(item1 = new MenuItem("Insert Customer")); 
			customer.add(item2 = new MenuItem("View Customer")); 
			customer.add(item3 = new MenuItem("Delete Customer")); 
			mbar.add(customer);  
		 
			Menu res = new Menu("UberEats"); 
			MenuItem item4, item5, item6; 
			res.add(item4 = new MenuItem("Insert Restaurant")); 
			res.add(item5 = new MenuItem("View Restaurant")); 
			res.add(item6 = new MenuItem("Delete Restaurant"));  
			mbar.add(res); 
			
			Menu order = new Menu("Order Details"); 
			MenuItem item7, item8, item9; 
			order.add(item7 = new MenuItem("Insert Order")); 
			order.add(item8 = new MenuItem("View Order")); 
			order.add(item9 = new MenuItem("Delete Order")); 
			mbar.add(order);			
			
			Menu payment= new Menu("Payment Details"); 
			MenuItem item10, item11, item12; 
			payment.add(item10 = new MenuItem("Insert Payment")); 
			payment.add(item11= new MenuItem("View Payment")); 
			payment.add(item12 = new MenuItem("Delete Payment")); 
			mbar.add(payment);
			
			Menu orders= new Menu("Orders"); 
			MenuItem item13, item14, item15; 
			orders.add(item13 = new MenuItem("Insert Orders")); 
			orders.add(item14= new MenuItem("View Orders")); 
			orders.add(item15 = new MenuItem("Delete Orders")); 
			mbar.add(orders);
			
			Menu orderFrom= new Menu("Order From"); 
			MenuItem item16, item17, item18; 
			orderFrom.add(item16 = new MenuItem("Insert Order From")); 
			orderFrom.add(item17= new MenuItem("View Order From")); 
			orderFrom.add(item18 = new MenuItem("Delete Order From")); 
			mbar.add(orderFrom);
			
			Menu pays= new Menu("Pays"); 
			MenuItem item19, item20, item21; 
			pays.add(item19 = new MenuItem("Insert Pays")); 
			pays.add(item20= new MenuItem("View Pays")); 
			pays.add(item21 = new MenuItem("Delete Pays")); 
			mbar.add(pays);
			
			Menu generates= new Menu("Generates"); 
			MenuItem item22, item23, item24; 
			generates.add(item22 = new MenuItem("Insert Generates")); 
			generates.add(item23= new MenuItem("View Generates")); 
			generates.add(item24 = new MenuItem("Delete Generates")); 
			mbar.add(generates);
			
			// register listeners
			item1.addActionListener(this); 
			item2.addActionListener(this); 
			item3.addActionListener(this); 
			item4.addActionListener(this); 
			item5.addActionListener(this); 
			item6.addActionListener(this); 
			item7.addActionListener(this); 
			item8.addActionListener(this); 
			item9.addActionListener(this);
			item10.addActionListener(this);
			item11.addActionListener(this);
			item12.addActionListener(this);
			item13.addActionListener(this);
			item14.addActionListener(this);
			item15.addActionListener(this);
			item16.addActionListener(this);	
			item17.addActionListener(this);	
			item18.addActionListener(this);	
			item19.addActionListener(this);
			item20.addActionListener(this);
			item21.addActionListener(this);
			item22.addActionListener(this);
			item23.addActionListener(this);
			item24.addActionListener(this);
			
					
			 // Anonymous inner class which extends WindowAdaptor to handle the Window event: windowClosing  
			addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent we) 
				{ 
					System.exit(0);	
				} 
			}); 
			
			//Frame properties
			setTitle("UBER EATS"); 
			Color clr = new Color(255, 102, 102);
			setBackground(clr); 
			setFont(new Font("Monaco", Font.BOLD, 20)); 
			setSize(900, 1000); 
		
			setVisible(true);	
			
	  }   
	  
	  public void actionPerformed(ActionEvent ae) 
	  { 
		  String arg = ae.getActionCommand(); 
		  if(arg.equals("Insert Customer"))
		  {
			  
			cardLO.show(home, "InsertCustomer"); 			
          }			
		 
		 else if(arg.equals("View Customer")) 
		 {
			
			cardLO.show(home, "UpdateCustomer"); 			
		 }
		 
		 else if(arg.equals("Delete Customer")) 
		 {
			 
			cardLO.show(home, "DeleteCustomer"); 			
		 }
		 else if(arg.equals("Insert Restaurant"))
		 {
			 
			 cardLO.show(home, "InsertRestaurant"); 
		 }
		 else if(arg.equals("Delete Restaurant"))
		 {
			 
			 cardLO.show(home, "DeleteRestaurant");
		 }
		 else if(arg.equals("View Restaurant"))
		 {
			
			 cardLO.show(home, "UpdateRestaurant");
		 }
		 else if(arg.equals("Insert Order"))
		 {
			 cardLO.show(home, "InsertOrder"); 
		 }
		 else if(arg.equals("Delete Order"))
		 {
			 cardLO.show(home, "DeleteOrder"); 
		 }
		 else if(arg.equals("View Order"))
		 {
			 cardLO.show(home, "UpdateOrder"); 
		 }
		 else if(arg.equals("Insert Payment"))
		 {
			 cardLO.show(home, "InsertPayment"); 
		 }
		 else if(arg.equals("View Payment"))
		 {
			 cardLO.show(home, "UpdatePayment"); 
		 }
		 else if(arg.equals("Delete Payment"))
		 {
			 cardLO.show(home, "DeletePayment"); 
		 }
		 else if(arg.equals("Insert Orders"))
		 {
			 cardLO.show(home, "InsertOrders");
		 }
		 else if(arg.equals("View Orders"))
		 {
			 cardLO.show(home, "UpdateOrders");
		 }
		 else if(arg.equals("Delete Orders"))
		 {
			 cardLO.show(home, "DeleteOrders");
		 }
		 else if(arg.equals("Insert Order From"))
		 {
			 cardLO.show(home, "InsertOrderFrom");
		 }
		 else if(arg.equals("View Order From"))
		 {
			 cardLO.show(home, "UpdateOrderFrom");
		 }
		 else if(arg.equals("Delete Order From"))
		 {
			 cardLO.show(home, "DeleteOrderFrom"); 
		 }
		 else if(arg.equals("Insert Pays"))
		 {
			 cardLO.show(home, "InsertPays");
		 }
		 else if(arg.equals("View Pays"))
		 {
			 cardLO.show(home, "UpdatePays");
		 }
		 else if(arg.equals("Delete Pays"))
		 {
			 cardLO.show(home, "DeletePays"); 
		 }
		 else if(arg.equals("Insert Generates"))
		 {
			 cardLO.show(home, "InsertGenerates");
		 }
		 else if(arg.equals("View Generates"))
		 {
			 cardLO.show(home, "UpdateGenerates");
		 }
		 else if(arg.equals("Delete Generates"))
		 {
			 cardLO.show(home, "DeleteGenerates"); 
		 }
		  
	  }
	  public static void main(String  ... args)
	  {
			new UberEatsDatabase();	  
	  }
}